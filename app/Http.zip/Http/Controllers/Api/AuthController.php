<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Traits\GeneralTrait;
use Illuminate\Http\Request;
use Auth;
use Illuminate\Support\Facades\DB;
use App\Models\ClinicInfo;
use App\Models\User;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Hash;


class AuthController extends Controller
{

    use GeneralTrait;

    /* login to all users (with different roles). */
    public function login(Request $request)
    {  
        $rules = [
            'email'     => 'required',
            'password'  => 'required'
        ];

        $validator = $this->validateRequest($request, $rules);
        if($validator->fails()) 
            return $this->returnErrorResponse(__('general.validate_error'), $validator);

        $token = Auth::guard('api')->attempt(['email'   =>  $request->email, 'password' => $request->password]);
        if(!$token) 
            return $this->returnErrorResponse(__('general.wrong_credentials'));


        $user = Auth::guard('api')->user();
        if($user->status == 0)
            return $this->returnErrorResponse(__('auth.email_locked'));
            
        $user->authenticated_subdomain = $request->route('subdomain');
        $user->save();
        
        //update status to suspend
        $subData = DB::connection('mysql_kyan')->table('domains')->where('subdomain', $request->route('subdomain'))->first();
        if(!$subData)
            return $this->returnErrorResponse(__('general.found_error'));
            
            
        //if the account is suspended by admin.
        if($subData->account_status == 'suspend')
            return $this->returnErrorResponse(__('auth.account_suspended'));
        
        // if(strtotime($subData->expiry_date) < strtotime(date('Y-m-d H:i:s'))){
        //     DB::connection('mysql_kyan')->table('domains')->where('subdomain', $request->route('subdomain'))->update(['account_status' => 'expired']);
        //     return $this->returnErrorResponse(__('auth.expiryRegisteration'));
        // }

        return $this->returnData(__('general.found_success'), 'data', $token);
    }


    /* retrieve authenticated user data.  - Must be authenticated (all) -*/
    public function getUserData(Request $request)
    {   
        $user = Auth::guard('api')->user();
        $clinic_image = ClinicInfo::first()->clinic_image;
        if($user->role == 2)
        {
            if($user->patient_info){
                $user->weight = $user->patient_info->weight;
                $user->address = $user->patient_info->address;
                $user->date = $user->patient_info->date;
                $user->generated_id = $user->patient_info->generated_id;    
            }
            unset($user->patient_info);
        }
        
        /* to retrieve the expiry date. */
        $subData = DB::connection('mysql_kyan')->table('domains')->where('subdomain', $request->route('subdomain'))->first();
        if(!$subData)
            return $this->returnErrorResponse(__('general.found_error'));

        $user->subdomain_expiry_date = $subData->expiry_date;
        $user->plan_days = $subData->days;
        $user->clinic_image = $clinic_image;
        return $this->returnData(__('general.found_success'), 'data', $user);
    }
    
    
    /*Check if the subdomain exists or not*/
    public function checkSubdomain($subdomain, Request $request)
    {
        $subdomain = $request->route('subdomain');

        //check the subdomain in kyanlabs database using mysql_kyan connection
        $data = DB::connection('mysql_kyan')->table('domains')->Where('subdomain', $subdomain)->first();
        if(!$data)
            return  $this->returnErrorResponse(__('general.subdomain_found_error'));


        $logo = ClinicInfo::first()->clinic_image;
        
        $resObj = new \stdClass();
        $resObj->doctor_name =  $data->doctor_name;
        $resObj->logo =  $logo;
        return $this->returnSuccessResponse(__('general.found_success'), $resObj);
    }
    

    /*password reset with link*/
    public function RequestPasswordReset(Request $request)
    {
        $user = User::where('email', $request->email)->first();
        if(!$user)
            return $this->returnErrorResponse(__('general.found_error'));
        
        
        $token = Str::random(32); 
        $user->remember_token = $token;
        $user->save();


        //send welcome mail to the doctor.
        $details = [
            'link' => 'https://' . $request->route('subdomain') . '.ayadty.com/el3yada/api/passwordReset/'.$token
        ];

        \Mail::to($request->email)->send(new \App\Mail\PasswordResetMail($details));

        
        return $this->returnSuccessResponse(__('general.linkSent'), $token);
    }
    
    public function PasswordReset(Request $request)
    {
        $user = User::where('email', $request->email)->where('remember_token', $request->token)->first();
        if(!$user)
            return $this->returnErrorResponse(__('general.found_error'));
        
        
        $user->remember_token = null;
        $user->password = Hash::make($request->password);
        $user->save();
        
        return $this->returnSuccessResponse(__('auth.password_changed'), $user);
    }
    /*end password reset operation with link*/
    
    
    /*password reset operation with code */    
    public function requestCodeResetPassword(Request $request)
    {
        $result = [];
        $user = User::where('email', $request->email)->first();
        if(!$user){
            return $this->returnErrorResponse(__('general.found_error'));
        }
        
        $arr_codes = json_decode($user->temp_codes);
        $code = rand(100000,999999);
        $arr_codes  = [];
        
        $arr_codes [] = $code;
        $user->temp_codes = json_encode($arr_codes);
        $user->save();


        //send email.
        $details = [];
        $details['name'] = $user->first_name . ' ' . $user->last_name;
        $details['email'] = $user->email;
        $details['subject'] = 'Code is';
        $details['code'] = $code;
        
        // \Mail::to($user->email)->send(new \App\Mail\ResetPasswordCode($details));
            
        
        return $this->returnSuccessResponse('code sent to your mail.');
    }
    private function generateToken()
    {
       // return hash_hmac('sha256', Str::random(40), config('app.key'));
       return Str::random(60);
    }
    public function CheckTheCodePasswordReset(Request $request)
    {
         $current_user =User::where('email', $request->email)->first();
        if(!$current_user){
            return $this->returnErrorResponse(__('general.found_error'));
        }

         $codes = json_decode($current_user->temp_codes);
         if(!is_array($codes)){
            return $this->returnErrorResponse('Opps! error happened.');
         }else{
            foreach($codes as $code)
            {
                if ($request->code == $code)
                {
                    $token = $this->generateToken();
                    DB::table('password_resets')->insert([
                        'email' => $request->email,    
                        'token' => $token,    
                        ]);
 
                    $current_user->temp_codes = null;
                    $current_user->save();
                    // $result['msg'] = 'Ok.';
                    // $result['status'] = true;
                    // $result['data'] = $token;
                    return $this->returnSuccessResponse('ok', $token);

                }
            }
         }

        
        return $this->returnErrorResponse('Wrong Code submitted.');
    }
    
    public function passwordResetWithCode(Request $request)
    {
        $chkRes = DB::table('password_resets')->where('token', $request->token)->where('email', $request->email)->get()->first();
        $result = [];
        if(!$chkRes)
        {
            return $this->returnErrorResponse('Opps! something wrong happened.');
        }else{
            DB::table('password_resets')->where('token', $request->token)->where('email', $request->email)->delete();
            User::where('email', $request->email)->update([
                'password'  => Hash::make($request->password)
                ]);
            return $this->returnSuccessResponse('Your password has been changed successfully.');
        }
    }

    /*end password reset operation with code.*/
}
