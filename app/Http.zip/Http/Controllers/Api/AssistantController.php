<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Traits\GeneralTrait;
use App\Models\Assistant;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class AssistantController extends Controller
{

    
    use GeneralTrait;
    public function list()
    {
        $data = User::where('role', 1)->paginate(10);
        return $this->returnData(__('general.found_success'), 'data', $data);    
    }
    public function save(Request $request)
    {
        $rules = [
            'first_name'    => 'required|max:255',
            'last_name'     => 'required|max:255',
            'email'         => 'required|max:255|email|unique:users,email',
            'phone'         => 'required|max:255',
            'image'         => 'mimes:png,jpg,jpeg|max:2048',
            'password'      => 'required|max:255',
        ];
        $validator = $this->validateRequest($request, $rules);
        if($validator->fails())
            return $this->returnErrorResponse(__('general.validate_error'), $validator);

        $image = '';
        if($request->hasFile('image'))
            $image = $this->UploadImage($request, 'users/assistants', 'image');
        
        $assistant = User::create([
            'first_name'    => $request->first_name, 
            'last_name'     => $request->last_name, 
            'email'         => $request->email, 
            'image'         => $image, 
            'phone'         => $request->phone, 
            'password'      => Hash::make($request->password),
            'role'          => 1,   //assistant
            'status'        => 1,
        ]);

        return $this->returnSuccessResponse(__('general.add_success'), $assistant);

    }
    public function update($subdomain,$id, Request $request)
    {
        $rules = [
            'first_name'    => 'required|max:255',
            'last_name'     => 'required|max:255',
            'email'         => 'required|max:255|email',
            'phone'         => 'required|max:255',
            'image'         => 'mimes:png,jpg,jpeg|max:2048',
            'password'      => 'max:255',
        ];
        $validator = $this->validateRequest($request, $rules);
        if($validator->fails())
            return $this->returnErrorResponse(__('general.validate_error'), $validator);

        $user = User::where('id', $id)->where('role', 1)->first();
        if(!$user)
            return $this->returnErrorResponse(__('general.found_error'));


        $image = '';
        if($request->hasFile('image'))
            $image = $this->UploadImage($request, 'users/assistants', 'image');
    
        $user->first_name    = $request->first_name;
        $user->last_name     = $request->last_name;
        $user->email         = $request->email;
        $user->phone         = $request->phone;

        if($request->hasFile('image'))
            $user->image     = $image;
        if($request->password)
            $user->password  = Hash::make($request->password);
            
        $user->save();

        return $this->returnSuccessResponse(__('general.edit_success'), $user);
        
    }
    public function delete($subdomain,$id)
    {
        $user = User::where('id', $id)->where('role', 1)->first();
        if(!$user)
            return $this->returnErrorResponse(__('general.found_error'));

        $user->delete();

        return $this->returnSuccessResponse(__('general.delete_success'));
    }

    public function search(Request $request)
    {
        $keyword = $request->keyword;
        $names = explode(' ', $request->keyword);

        $users = User::where('role', 1)->where(function($query) use ($keyword, $names){
            $query->where('first_name','LIKE', '%'. $names[0] . '%');
            if(isset($names[1]))
                $query->orWhere('last_name','LIKE', '%'. $names[1] . '%');
            $query->orWhere('email','LIKE', '%'. $keyword . '%');
            $query->orWhere('phone','LIKE', '%'. $keyword . '%'); 
        })->paginate(10);
            

            return $this->returnData(__('general.found_success'), 'data', $users);
    }

    public function deleteAll(Request $request)
    {
        $rules = ['ids'=> 'required'];
        $ids = explode(',', $request->ids);
        $result = User::whereIn('id', $ids)->where('role', 1)->delete();
        if($result > 0)
            return $this->returnSuccessResponse(__('general.delete_all', ['num' => $result]) );
        else
            return $this->returnErrorResponse(__('general.delete_error'));
    }
}
