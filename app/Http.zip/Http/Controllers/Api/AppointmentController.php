<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Traits\GeneralTrait;
use App\Models\Appointment;
use App\Models\ClinicInfo;
use DateInterval;
use DateTime;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\App;

class AppointmentController extends Controller
{
    use GeneralTrait;

    private $rules =  [
        'from'          => 'required',
        'to'            => 'required',
        'duration'      => 'numeric',
        'doctor_id'     => 'required',
    ];
    public function list(Request $request)
    {
        //return response()->json(date('Y-m-d H:i:s'));
        $data = Appointment::with('visit', 'visit.patient')->where('doctor_id', $request->doctor_id)->where('from', '>=', date('Y-m-d H:i:s'))->orderBy('from', 'asc')->get();
        //return response()->json($data);
        
        $clinic_info = ClinicInfo::first();
        foreach($data as $d)
        {
            if($d->visit)
            {
                if($d->visit->type == 'diagnosis')
                {
                    $d->visit->amount = $clinic_info->amount;
                }else{
                    
                    $d->visit->amount = $clinic_info->consultation_amount;
                }
            }
        }
        return $this->returnData(__('general.found_success'), 'data', $data);
    }

    public function save(Request $request)
    {
        //return date("h:i:sa");

        $validator = $this->validateRequest($request, $this->rules);
        if($validator->fails())
            return $this->returnErrorResponse(__('general.validate_error'), $validator);


        if($request->to <= $request->from)
            return $this->returnErrorResponse(__('general.errorAppointment'));




        $data = $this->checkFromToAppointment($request->from, $request->to,null, $request->doctor_id);
       // return response()->json($data);
        if($data && count($data))
            return $this->returnErrorResponse(__('general.errorAppointment'));
    

        
        if($request->duration){
                $duration = $request->duration;

                $begin = new DateTime( $request->from);
                $end   = new DateTime( $request->to);

                $dataRes = $this->checkFromToAppointment($begin, $end,null ,$request->doctor_id);
                //return response()->json($dataRes);
                if($dataRes && count($dataRes))
                    return $this->returnErrorResponse(__('general.errorAppointment'));

                $dataRes = NULL;
                
                //get Dates
                $start_date = date('Y-m-d', strtotime($request->from));
                $end_date = date('Y-m-d', strtotime($request->to));
                
                //get times
                $start_time =   date_format($begin, 'H:i:s');
                $end_time   =   date_format($end, 'H:i:s');

                //this snippets of code to create same appointments in different days.
                if($start_date <= $end_date)
                {
                    $data = [];
                    while($start_date <= $end_date){
                        $begin_repeated = new DateTime($start_date.' ' . $start_time);
                        $end_repeated   = new DateTime($start_date. ' ' . $end_time);
                        
                        $temp_result = $this->addAppointmentDurationHelper($begin_repeated, $end_repeated, $duration, $request->doctor_id);
                        $data = array_merge($data, $temp_result);
                        $start_date = date('Y-m-d', strtotime($start_date . ' +1 day'));
                    }
                }

                //store the list
                $this->addAppointmentsHelper($data);
        }else{
            //single appointment
            $from = date('Y-m-d H:i:s',strtotime($request->from));
            $to = date('Y-m-d H:i:s',strtotime($request->to));
            $data = $this->addAppointmentHelper($from, $to, $request->doctor_id);
        }
        
          //  Appointment::insert($data);
       return $this->returnSuccessResponse(__('general.add_success'), $data);
    }
    
    //prepare the arry to be inserted in database (use duration).
    private function addAppointmentDurationHelper($begin, $end, $duration, $doctor_id)
    {
        $data = [];
        for($i = $begin; $i <= $end; ){
                    
            $from = $i->format('Y-m-d H:i:s');

            $i->add(new DateInterval('PT' . $duration . 'M'));  //increase the duration

            if($i > $end)
                break;

            $to = $i->format('Y-m-d H:i:s');

            $data [] = [
                        'from'  => $from,
                        'to'  => $to,
                        'status'  => 0,
                        'doctor_id'  => $doctor_id,
                    ];
        }
        return $data;

    }
    
    //Method to check the appointment to avoit appointments conflict.
    private function checkFromToAppointment($from, $to, $id=null, $doctor_id=null)
    {
        
            //check to avoid conflict
            $data = \App\Models\Appointment::where(function($query)use ($from, $to,$id,$doctor_id){
                $query->where('from', '<=', $from)->Where('to', '>', $from);
                if($doctor_id !== null)
                    $query->where('doctor_id', $doctor_id);
                    
                if($id !== null) //except the updated one.
                    $query->where('id', '<>', $id);
            })->orWhere(function($query)use($from, $to, $id,$doctor_id){
                $query->where('from', '<', $to)->Where('to', '>', $to);
                if($doctor_id !== null)
                    $query->where('doctor_id', $doctor_id);

                if($id !== null)
                    $query->where('id', '<>', $id);
                    
            })->orWhere(function($query)use($from, $to, $id,$doctor_id){
            $query->where('from', '>', $from)
                ->Where('from', '<', $to)
                ->where('to', '>', $from)
                ->Where('to', '<', $to);
                
                if($doctor_id !== null)
                    $query->where('doctor_id', $doctor_id);

                if($id !== null)
                    $query->where('id', '<>', $id);
            })->get();

        
        return $data;
    }
    
    //Save array of appointments.
    private function addAppointmentsHelper($data)
    {
        $data = Appointment::insert($data);
        return $data;
    }

    
    //Save sigle appointment
    private function addAppointmentHelper($from, $to, $doctor_id)
    {
        $data = Appointment::create([
            'from'  => $from,
            'to'  => $to,
            'status'  => 0,
            'doctor_id'  => $doctor_id,
        ]);
        return $data;
    }
    public function update($subdomain, $id, Request $request)
    {
        $validator = $this->validateRequest($request, $this->rules);
        if($validator->fails())
            return $this->returnErrorResponse(__('general.validate_error'), $validator);

        if($request->to <= $request->from)
            return $this->returnErrorResponse(__('general.errorAppointment'));



        $data = $this->checkFromToAppointment($request->from, $request->to, $id, $request->doctor_id);

        if($data && count($data))
            return $this->returnErrorResponse(__('general.errorAppointment'));

        $data = Appointment::find($id);
        if(!$data)
            return $this->returnErrorResponse(__('general.found_error'));


        $data->from = $request->from;
        $data->to = $request->to;
        $data->save();

        return $this->returnSuccessResponse(__('general.edit_success'), $data);
    }

    public function delete($subdomain,$id)
    {
        $data = Appointment::find($id);
        if(!$data)
            return $this->returnErrorResponse(__('general.found_error'));

        $data->delete();

        return $this->returnSuccessResponse(__('general.delete_success'), $data);
    }

    public function filterAppointments(Request $request)
    {

        if($request->filter != ''){
            $strings = $request->filter;
            $arr = explode(',', $strings);    
            $data = Appointment::with('visit', 'visit.patient')->where('doctor_id', $request->doctor_id)->whereIn('status', $arr)->where('from', '>=', date('Y-m-d H:i:s'))->get();
        }
        else{
            $data = Appointment::with('visit', 'visit.patient')->where('doctor_id', $request->doctor_id)->where('from', '>=', date('Y-m-d H:i:s'))->get();
        }
        
        $clinic_info = ClinicInfo::first();
        foreach($data as $d)
        {
            if($d->visit)
            {
                if($d->visit->type == 'diagnosis')
                {
                    $d->visit->amount = $clinic_info->amount;
                }else{
                    
                    $d->visit->amount = $clinic_info->consultation_amount;
                }
            }
        }

        return $this->returnData(__('general.found_success'),'data', $data);
    }
}
