<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Traits\GeneralTrait;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use App\Models\ClinicInfo;
use App\Models\Visit;
use Illuminate\Support\Facades\Http;

class PatientController extends Controller
{
    use GeneralTrait;
    public function list()
    {
        $data = tap(User::where('role', 2)->with('patient_info')->paginate(10))->map(function($item){
            return $this->editResponse($item);
        });

        return $this->returnData(__('general.found_success'), 'data', $data);
    }

    public function save($subdomain, Request $request)
    {
        $rules = [
            'first_name'    => 'required|max:255',
            'last_name'     => 'required|max:255',
            'email'         => 'required|max:255|email|unique:users,email',
            'password'      => 'required|max:255',
            'phone'         => 'required|max:255',
            'image'         => 'mimes:png,jpeg,jpg|max:2048',
            'address'       => 'max:255',
            'date'          => 'max:255',
            'weight'        => 'max:255',
        ];

        $validator = $this->validateRequest($request, $rules);
        if($validator->fails())
            return $this->returnErrorResponse(__('general.validate_error'), $validator);

        $image = '';
        if($request->hasFile('image'))
        {
            $image = $this->UploadImage($request, 'users/patients', 'image');
        }
        
        $clinicInfo  = ClinicInfo::first();
        if(!$clinicInfo)
            return $this->returnErrorResponse(__('general.found_error'));
        $data = User::create([
            'first_name'    => $request->first_name,
            'last_name'     => $request->last_name,
            'email'         => $request->email,
            'password'      => Hash::make($request->password),
            'phone'         => $request->phone,
            'image'         => $image,
            'role'          => 2,
            'status'        => 1,
        ]);
        $data->patient_info()->create([
            'address'   => $request->address,
            'date'  => $request->date,
            'weight'    => $request->weight,
            'generated_id'  => $data->id . uniqid(),
        ]);


        $data = $this->editResponse($data);


    // $response =Http::withBody('
    //             {
    //         "messaging_product": "whatsapp",
    //         "to": "+2'.$request->phone.'",
    //         "type": "template",
    //         "template": {
    //             "name": "patient_welcome",
    //             "language": {
    //                 "code": "en"
    //             },
    //             "components": [
    //                 {
    //                     "type": "header",
    //                     "parameters": [
    //                         {
    //                             "type": "text",
    //                             "text": "'.$request->first_name . ' ' . $request->last_name.'"
    //                         }
    //                     ]
    //                 },
    //                 {
    //                     "type": "body",
    //                     "parameters": [
    //                         {
    //                             "type": "text",
    //                             "text": "'.$clinicInfo->doctor_name.'"
    //                         },
    //                         {
    //                             "type": "text",
    //                             "text": "'.$request->email.'"
    //                         },
    //                         {
    //                             "type": "text",
    //                             "text": "'.$request->password.'"
    //                         },{
    //                             "type": "text",
    //                             "text": "https://'.$subdomain.'.ayadty.com"
    //                         },
    //                     ]
    //                 }
    //             ]
    //         }
    //     }
    // ', 'application/json')
    // ->withToken(env('WHATSAPP_API_KEY'))
    // ->post('https://graph.facebook.com/v14.0/111701565072005/messages');
    
    //     $response = json_decode($response);
        // if(isset($response) && isset($response->error))
        //     return $this->returnErrorResponse('Invalid Number');


        return $this->returnSuccessResponse(__('general.add_success'), $data);
    }
    public function update($subdomain, $id, Request $request)
    {
        $rules = [
            'first_name'    => 'required|max:255',
            'last_name'     => 'required|max:255',
            'email'         => 'required|max:255|email',
            'password'      => 'max:255',
            'phone'         => 'required|max:255',
            'image'         => 'mimes:png,jpeg,jpg|max:2048',
            'address'       => 'max:255',
            'date'          => 'max:255',
            'weight'        => 'max:255',
        ];

        $validator = $this->validateRequest($request, $rules);
        if($validator->fails())
            return $this->returnErrorResponse(__('general.validate_error'), $validator);
        
        /** Check wheather user exists or not. */
        $patient = User::where('id', $id)->where('role', 2)->first();
        if(!$patient)
            return $this->returnErrorResponse(__('general.found_error'));

        /** check if the email is exist in another record. */
        $found_email = User::where('id', '!=', $id)->where('email', $request->email)->first();
        if($found_email)
            return $this->returnErrorResponse(__('validation.unique',['attribute'=> 'email']));

        /** if there's an image in request. */
        $image = '';
        if($request->hasFile('image'))
        {
            $image = $this->UploadImage($request, 'users/patients', 'image');
        }
        
        /** update the main patient info */
        $patient->first_name = $request->first_name;
        $patient->last_name = $request->last_name;
        $patient->email = $request->email;
        $patient->phone = $request->phone;

        if($request->password)
            $patient->password = Hash::make($request->password);
        if($request->image)
            $patient->image = $image;
        
        /** update the others patient info.*/
        $patient->patient_info()->update([
            'weight'    => $request->weight,
            'date'      => $request->date,
            'address'   => $request->address,
        ]);

        $patient->save();

        /** edit the response of the object to be only one object contain key:value. */
        $patient = $this->editResponse($patient);

        return $this->returnSuccessResponse(__('general.edit_success'), $patient);

    }
    public function delete($subdomain,$id)
    {
        $data = User::where('id', $id)->where('role', 2)->first();
        if(!$data)
            return $this->returnErrorResponse(__('general.found_error'));


        $data->delete();
        return $this->returnSuccessResponse(__('general.delete_success'));
    }
    public function searchByGeneratedId($subdomain, $generated_id)
    {
        $data = User::with('visits.appointment')->join('patient_infos', 'users.id', 'patient_infos.user_id')
                ->select(
                    'users.id as id', 'first_name', 'last_name', 
                    'email', 'phone', 'image', 'role', 'users.created_at', 'users.updated_at', 
                    'patient_infos.weight','patient_infos.address',
                    'patient_infos.generated_id','patient_infos.id as pateint_info_id',
                    )
                ->where('users.role', 2)
                ->where('patient_infos.generated_id', $generated_id)
                ->first();

        if(!$data)
            return $this->returnErrorResponse(__('general.found_error'));

        return $this->returnData(__('general.found_success'), 'data', $data);
    }
    public function getById($subdomain, $id)
    {
        
        $amount = ClinicInfo::first()->amount;
        $consultation_amount  = ClinicInfo::first()->consultation_amount;
        $data = User::with('visits.appointment')->join('patient_infos', 'users.id', 'patient_infos.user_id')
                ->select(
                    'users.id as id', 
                    'first_name', 
                    'last_name', 
                    'email', 
                    'phone', 
                    'image', 
                    'role', 
                    'users.created_at', 
                    'users.updated_at', 
                    'patient_infos.weight',
                    'patient_infos.address',
                    'patient_infos.date', 
                    'patient_infos.generated_id',
                    'patient_infos.id as pateint_info_id',
                    )
                ->where('users.role', 2)
                ->where('users.id', $id)
                ->first();

        if(!$data)
            return $this->returnErrorResponse(__('general.found_error'));
            
        foreach($data->visits as $rec)
        {
            if($rec->amount ==0)
            {
                if($rec->type == 'follow')
                    $rec->amount = $consultation_amount;
                else
                    $rec->amount = $amount;
            }
                
        }

        return $this->returnData(__('general.found_success'), 'data', $data);

    }
    public function GetByName(Request $request)
    {
        
        
        $names = explode(' ', $request->keyword);
        $data = User::with('visits.appointment')->join('patient_infos', 'users.id', 'patient_infos.user_id')
        ->select(
            'users.id as id', 
            'first_name', 
            'last_name', 
            'email', 
            'phone', 
            'image', 
            'role', 
            'users.created_at', 
            'users.updated_at', 
            'patient_infos.weight',
            'patient_infos.address',
            'patient_infos.generated_id',
            'patient_infos.id as pateint_info_id',
            )   
        ->where('users.role', 2)
        ->where(function($query) use($names){
            
            $query->where('users.first_name','LIKE', '%'. $names[0] . '%');
            
            if(isset($names[1]))
                $query->orWhere('users.last_name','LIKE', '%'. $names[1] . '%');

        })
        ->paginate(10);
        return $this->returnData(__('general.found_success'), 'data', $data);

    }
    private function editResponse($patient)
    {
        if( $patient->patient_info){
            $patient->weight = $patient->patient_info->weight;
            $patient->address = $patient->patient_info->address;
            $patient->date = $patient->patient_info->date;
            $patient->generated_id = $patient->patient_info->generated_id;
        }
        unset($patient->patient_info);
        return $patient;

    }

    public function getAppointments($subdomain, $patient_id)
    {
        $patient = User::where('id', $patient_id)->where('role', 2)->first();
        if(!$patient)
            return $this->returnErrorResponse(__('general.found_error'));

        //need doctor id
        $data = Visit::select('id','user_id','appointment_id','status')->where('user_id', $patient_id)->with('appointment', 'appointment.doctor')->paginate(10);


        return $this->returnData(__('general.found_success'), 'data', $data);
        
    }
    
    
}
