<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Schema;

class CreateUsersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('users', function (Blueprint $table) {
            $table->id();
            $table->string('first_name');
            $table->string('last_name');
            $table->string('email')->unique();
            $table->timestamp('email_verified_at')->nullable();
            $table->string('password');
            $table->string('phone');
            $table->string('image')->nullable();
            $table->tinyInteger('role')->default(1)->comment('0 S.Admin, 1 Assistant and 2 Patient');
            $table->text('permission')->nullable();
            $table->tinyInteger('status')->default(1)->comment('0 inactive, 1 active');
            $table->rememberToken();
            $table->string('authenticated_subdomain')->nullable();
            $table->timestamps();
            $table->longText('temp_codes')->nullable();
            $table->integer('amount')->default(450)->nullable();
            $table->integer('follow_up')->default(200)->nullable();
        });


        // DB::table('users')->insert([
        //     'first_name'    => 'Omar',
        //     'last_name'     => 'Tarek',
        //     'password'      => Hash::make('123'),
        //     'email'         => 'doctor@doctor.com',
        //     'phone'         => '123456789',
        //     'image'         => '',
        //     'role'          => 0,
        // ]);
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('users');
    }
}
